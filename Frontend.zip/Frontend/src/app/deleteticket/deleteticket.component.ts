import { Component } from '@angular/core';

@Component({
  selector: 'app-deleteticket',
  templateUrl: './deleteticket.component.html',
  styleUrls: ['./deleteticket.component.css']
})
export class DeleteticketComponent {

}
