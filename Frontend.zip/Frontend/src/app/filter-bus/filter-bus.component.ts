import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-bus',
  templateUrl: './filter-bus.component.html',
  styleUrls: ['./filter-bus.component.css']
})
export class FilterBusComponent implements OnInit {
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  constructor(){
    
  }

}
